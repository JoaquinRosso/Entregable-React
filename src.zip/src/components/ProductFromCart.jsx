function ProductFromCart({ product, cartItem, setCartItem }) {
  return (
    <>
      <p>{product.name}</p>
    </>
  );
}
export default ProductFromCart;
