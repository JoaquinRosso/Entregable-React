import ProductFromCart from "./ProductFromCart";
function ShoppingCart({ cartItem, setCartProduct }) {
  return (
    <>
      {cartItem.map(function (product) {
        return <ProductFromCart product={product} />;
      })}
    </>
  );
}
export default ShoppingCart;
